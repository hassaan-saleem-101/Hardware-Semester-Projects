#include <Arduino.h>
#include <DHT.h>
#include <DHT_U.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <keypad.h>

const int lt = 9; // SDA will always be at A4 and SCL will always be at A5 of arduino

LiquidCrystal_I2C lcd(0x27, 16, 2);

#define DHTTYPE 11 // this tells us what sensor we are using

#define pin_fan 10 // fan works on analogue pins this is the gate pin for the MOSFET

#define light_bulb 11 // this is for bulb

int dht_pin = 2; // pin number at which the sensor is connected

float temp_read = 0.0;

bool temp_show = true; // outputs 1 if true and 0 when false ....

int kp = 50;
int ki = 30;
int kd = 1200;
int PID_p = 0;
int PID_i = 0;
int PID_d = 0;
float last_kp = 0;
float last_ki = 0;
float last_kd = 0;

float PID_error = 0;
float previous_error = 0;
float elapsedTime, Time, timePrev;
float PID_value = 0;
float last_set_temperature = 0;
int set_temperature = 0; // this must be in float ...

DHT dht_sensor(2, DHTTYPE); // created an instamce of type dht and passed pin number and type of sensor
                            //  we are using as parameters

void data_clear();
void key_press();
void reading_temp();
void setting_PID_value();
int set_value();
void print_temp();
void clear_set_value();

const byte rows = 4;
const byte columns = 3;

#define data_length 8 // length of data + 1 with null character ....
#define check_length 4

char data[check_length]; // character to hold data input ...

char value_1[data_length]; // one array one counter one clear ...
char value_2[data_length];

char compare_1[check_length] = "10#";

char compare_2[check_length] = "11#";

char compare_3[check_length] = "12#";

char compare_4[check_length] = "13#";

byte data_count = 0; // counter for character enteries ...
byte value_count = 0;

char key; // character to hold the key input ...

char keys[rows][columns] = {
    {'1', '2', '3'},
    {'4', '5', '6'},
    {'7', '8', '9'},
    {'*', '0', '#'}};

byte row_pins[rows] = {3, 4, 5, 6};
byte col_pins[columns] = {7, 8, 12};

Keypad keypad(makeKeymap(keys), row_pins, col_pins, rows, columns);

void setup()
{
  // put your setup code here, to run once:
  Serial.begin(9600);
  analogWrite(lt, 50);
  lcd.init();
  lcd.backlight();

  Serial.println("testing the dht sensor");

  dht_sensor.begin(); // the sensor will start taking values

  pinMode(pin_fan, OUTPUT);
  pinMode(light_bulb, OUTPUT);

  // turning the fan off
  // digitalWrite(pin_fan, LOW);
}

void loop()
{
  // put your main code here, to run repeatedly:

  reading_temp();

  while (key != '*')
  {
    key_press();
  }

  setting_PID_value();

  print_temp();

  // delay(100);
}

void reading_temp()
{

  delay(2000); // we have to wait for seconds to between temperatures

  temp_read = dht_sensor.readTemperature();

  set_temperature = analogRead(A1);
  set_temperature = map(set_temperature, 0, 1024, 0, 100);

  // delay(100);
}

void setting_PID_value()
{

  if (set_temperature > temp_read)
  {
    PID_error = set_temperature - temp_read + 3;
  }

  else if (set_temperature < temp_read)
  {
    PID_error = temp_read - set_temperature + 3;
  }

  PID_p = 0.01 * kp * PID_error;

  PID_i = 0.01 * PID_i + (ki * PID_error);

  timePrev = Time;

  Time = millis();

  elapsedTime = (Time - timePrev) / 1000;

  PID_d = 0.01 * kd * ((PID_error - previous_error) / elapsedTime);

  PID_value = PID_p + PID_i + PID_d;

  if (PID_value < 0)
  {
    PID_value = 0;
  }
  if (PID_value > 255)
  {
    PID_value = 255;
  }

  // analogWrite(10,PID_value);

  if (set_temperature < temp_read)
  {
    analogWrite(light_bulb, 255);
    analogWrite(pin_fan, 255 - PID_value);
  }

  else if (set_temperature > temp_read)
  {
    analogWrite(light_bulb, 255 - PID_value);
    analogWrite(pin_fan, 255);
  }

  previous_error = PID_error;
}

void key_press()
{

  key = keypad.getKey(); // looking for key press

  if (key)
  {
    data[data_count] = key; // enter the key into an array and increment the counter ....
    lcd.setCursor(data_count, 0);
    lcd.print(data[data_count]);
    data_count++;
  }

  if (data_count == check_length - 1) /// see if you have reached the compare length ...
  {

    lcd.clear();
    // data_clear();

    if (!strcmp(data, compare_1))
    {

      Serial.print('1');

      delay(400);

      lcd.clear();
      lcd.setCursor(0, 0);
      lcd.print("Set  temperature");
      lcd.setCursor(0, 1);

      set_temperature = set_value();

      lcd.print(set_temperature); // calculate set temp
    }

    if (!strcmp(data, compare_2))
    {

      Serial.print('2');

      delay(400);

      lcd.clear();
      lcd.setCursor(0, 0);
      lcd.print("Set   KP  value  ");
      set_value();
      lcd.setCursor(0, 1);
      kp = set_value();
      lcd.print(kp);
    }

    if (!strcmp(data, compare_3))
    {

      Serial.print('3');

      delay(400);

      lcd.clear();
      lcd.setCursor(0, 0);
      lcd.print("Set   KI  value  ");
      lcd.setCursor(0, 1);
      ki = set_value();
      lcd.print(ki);
    }

    if (!strcmp(data, compare_4))
    {

      Serial.print('4');

      delay(400);

      lcd.clear();
      lcd.setCursor(0, 0);
      lcd.print("Set   KD  value  ");
      lcd.setCursor(0, 1);
      kd = set_value();
      lcd.print(kd);
    }

    else if (strcmp(data, compare_1) || strcmp(data, compare_2) || strcmp(data, compare_3) || strcmp(data, compare_4))
    {

      lcd.print("incorrect");
      delay(100);
    }

    lcd.clear();
    data_clear();
  }
}

int set_value()
{

  int result = 0;

  for (int i = 0; i < 3; i++) // mainey kuch aesea karna hai for loop sey tabhi nikley jab key press hou
  {
    key = keypad.getKey();

    if (key != '*')
    {
      // key = keypad.getKey();

      int j = int(key);

      value_1[value_count] = j - 48;

      value_count++;

      int digits = floor(log10(value_1[i])) + 1;
      result *= pow(10, digits);
      result += value_1[i];
    }
  }

  // clear_set_value();

  return result;
}

void print_temp()
{

  lcd.setCursor(0, 0); // setCursor(column number, row number);
  lcd.print("real temp: ");
  lcd.setCursor(12, 0);
  lcd.print(temp_read);
  // delay(100);

  lcd.setCursor(0, 1);
  lcd.print("set temp: ");
  lcd.setCursor(12, 1);
  lcd.print(set_temperature);

  Serial.println();
}

void data_clear()
{

  while (data_count != 0) // go through the array and clear the data ....
  {

    data[data_count] = 0;

    data_count--;
  }

  return;
}

void clear_set_value()
{

  while (value_count != 0) // go through the array and clear the data ....
  {

    value_1[value_count] = 0;

    value_count--;
  }

  return;
}
