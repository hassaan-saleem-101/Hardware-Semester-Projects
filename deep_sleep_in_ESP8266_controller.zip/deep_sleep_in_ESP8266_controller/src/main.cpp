#include <Arduino.h>
#include <DHT.h> // Including library for dht
#include <DHT_U.h>
#include <MQ2.h>

#define DHTPIN D7  // pin where the dht11 is connected
#define DHTTYPE 11 // Initialize dht type as DHT 11

// float voltage_Sense;     // Float var voltage_sense
int sensor_value = A0; // Float var sensor value

#define led_set_timeout D5
#define led_pin D6

MQ2 mq2(sensor_value);

DHT dht(DHTPIN, DHTTYPE);

void setup()
{
  Serial.begin(115200);
  Serial.setTimeout(2000);
  pinMode(led_pin, OUTPUT);
  pinMode(led_set_timeout, OUTPUT);
  dht.begin();
  mq2.begin();
  delay(1000);

  // Wait for serial to initialize.
  while (!Serial)
  {
    digitalWrite(led_set_timeout, LOW);
    delay(200);
  }

  digitalWrite(led_set_timeout, HIGH);
  delay(200);

}

void loop()
{
  // put your main code here, to run repeatedly:

  digitalWrite(led_pin, LOW);

  delay(2000);

  static float *values = mq2.read(true); // set it false if you don't want to print the values in the Serial

  // voltage_Sense = sensor_value / 1024 * 5.0; // Voltage / 1024 * 5.0

  delay(2000);

  float h = dht.readHumidity();
  float t = dht.readTemperature();
  float co = mq2.readCO();

  if (isnan(h) || isnan(t) || isnan(co))
  {
    Serial.println("Failed to read from DHT sensor!");
    delay(1000);
    Serial.println("Failed to read from Mq2 sensor!");
    delay(1000);
    return;
  }

  Serial.print("Temperature: ");
  Serial.println(t);
  delay(1000);
  Serial.print(" degrees Celcius, Humidity: ");
  Serial.println(h);
  delay(1000);
  Serial.print("CO in ppm: ");
  Serial.println(co);

  digitalWrite(led_pin, HIGH);
  delay(1200);

  // 30 seconds Deep sleep, when D0 in NodeMCU board is connected to the RESET pin, the ESP8266 wakes up 
  Serial.println("I'm awake, but I'm going into deep sleep mode for 30 seconds");

  ESP.deepSleep(30e6);
}
