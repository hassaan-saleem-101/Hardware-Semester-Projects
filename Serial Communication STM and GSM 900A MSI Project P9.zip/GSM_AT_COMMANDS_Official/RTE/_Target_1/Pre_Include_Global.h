
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'lab9_lcd_display' 
 * Target:  'Target 1' 
 */

#ifndef PRE_INCLUDE_GLOBAL_H
#define PRE_INCLUDE_GLOBAL_H

/* Keil::Device:STM32Cube HAL:Common:1.7.13 */
#define USE_HAL_DRIVER


#endif /* PRE_INCLUDE_GLOBAL_H */
