#include <stdio.h>
#include <stm32f4xx.h>
#include <string.h>
#include <stdint.h>
#include <stdlib.h>

#define RX_BUFFER_SIZE 128 // bytes

void delayMS(int delay);
void USART2_Init (void);
char USART2_Read(void);
void USART_Text_Write( char *text);
char USART2_Write (char ch);
int GSM_Compare_GSMData_With(const char* string);
void GSM_Send_AT_Command(char* AT_CMD);

void GSM_Send_SMS(char* Message, char* phone_number);
void GSM_Receive_SMS(void);

void Phone_Send_SMS(void);
void Phone_Receive_SMS(void);

void GSM_Init(void);
void GSM_Clear_RX_buffer(void);


/* "RX buffer" to store incoming data from GSM module */
char RX_Buffer[RX_BUFFER_SIZE];

/*"Incoming_SMS_Phone_num" to store incomming SMS number */
char Incoming_SMS_Phone_Num[13] = {'\0'};

/*Incoming_SMS_Message" to store SMS received */
char Incoming_SMS_Message[100] ={'\0'};

/// interfacing the lcd


void lcd_ini(void);
void lcd_data(char j);
void lcd_cmd(char i);
char button(void);

volatile uint32_t msTicks; /* counts 1ms timeTicks */
/*----------------------------------------------------------------------------
 SysTick_Handler
*----------------------------------------------------------------------------*/
void SysTick_Handler(void) {
 msTicks++;
}
void Delay (uint32_t dlyTicks) { 
uint32_t loop=0,dly=0,loope=0;
dly = dlyTicks ; 
for(loop=0;loop<dly;loop++){
for(loope=0;loope<29000;loope++){
__nop();
}
}
}
unsigned long LCDDATA=0;
char c;
int main (void) {
 SystemCoreClockUpdate(); // Get Core Clock Frequency
 /*----------------------------------------------------------------------------
 Add your code to enable Ports that can be used for this program.
*----------------------------------------------------------------------------*/ 
	
	RCC->AHB1ENR |= (1<<0); //port A is on
  GPIOA->MODER |= (1<<10);   // PA5 pin is output moder 5 for Led 
//	USART2_Init ();
	
	RCC -> AHB1ENR |= (1<< 3); // D GPIO is on 
	
	
	GPIOD -> MODER = 0x00005000; // setting pin directin from pb0 to pb15; it is in output mode .... 
	
	GPIOD -> OTYPER = 0x00000003; 
	
	GPIOD -> OSPEEDR = 0xAAAAAAAA;
	
	GPIOD -> PUPDR = 0x00000000;

	
	
//// lcd  display 
	
		RCC -> AHB1ENR |= (1<< 2); // C GPIO is on 
GPIOC->MODER=0X55200000;
GPIOC->OTYPER=0X00000000;
GPIOB->OSPEEDR=0XAAAAAAAA;
GPIOB->PUPDR=0X00000000;
	
	
	/////////////////////////////////////////////////////
	
	
	RCC -> AHB1ENR |= (1<< 4); // if (1<< 0) then GPIOE 0 will enable so number indicates which is on of rcc register ... 
	
  GPIOE->MODER = 0x55555555; // setting pin direction from pe0 to pe 15;
	
  GPIOE -> OTYPER = 0x0000FF00;

  GPIOE -> OSPEEDR = 0xAAAAAAAA;
	
	GPIOE -> PUPDR = 0x00000000;


RCC -> AHB1ENR |= (1<<1);  /// B GPIO on 

GPIOB ->MODER = 0x00000005; // setting pin directin from pb0 to pb15;
	
	GPIOB -> OTYPER = 0x00000003;
	
	GPIOB -> OSPEEDR = 0xAAAAAAAA;
	
	GPIOB -> PUPDR = 0x00000000;


 GPIOB->BSRR = ((1 << (0 +16))); // LCD RW -> 0

lcd_ini();
lcd_cmd(0x80); // line 1
lcd_data('P'); // S
lcd_data('R'); // T
lcd_data('E'); // SP
lcd_data('S'); // T
lcd_data('1'); // D
lcd_data(' ');
lcd_data('F');
lcd_data('O');
lcd_data('R');
lcd_data(' ');
lcd_data('S'); // D
lcd_data('E');// D
lcd_data('N');
lcd_data('D');
lcd_cmd(0xC0); // line 2

lcd_data('P'); // S
lcd_data('R'); // T
lcd_data('E'); // SP
lcd_data('S'); // T
lcd_data('2'); // D
lcd_data(' ');
lcd_data('T');
lcd_data('O');
lcd_data(' ');
lcd_data('R'); // D
lcd_data('E');// D
lcd_data('C');
lcd_data('E');
lcd_data('I');
lcd_data('V');
lcd_data('E');

//USART2_Init();

	while(1){
		
		button();	
	
	/*Check GSM for Incoming SMS*/
//		if(GSM_Compare_GSMData_With("MESSAGE"))
//		{
//			Phone_Receive_SMS();
//		}
//		
	    Delay(10);
		
	}
	
}

char button(void){
char key_pressed = 0;
	
//GPIOA->BSRR = (1 << 11);
//GPIOA->BSRR = (1 << (12+16) );

		GPIOD->BSRR = (1 << 7);
	
	GPIOD->BSRR = (1 << (6 + 16));

	
 if((GPIOD->IDR & 0x00000002) == 0x00000002) {
key_pressed = 1;
	 
lcd_cmd(0xC7); // line 2
lcd_cmd(0x01);
lcd_data('T');
lcd_data('E');
lcd_data('X');
lcd_data('T');
lcd_data(' ');
lcd_data('S');
lcd_data('E');
lcd_data('N');
lcd_data('T');
	 
	 Delay(10);
GPIOD->IDR = 0x00000000;
	 
/* Initialize GSM A6 Module */
	
	GSM_Init();
	
Phone_Send_SMS();
	 
}
 
// End if( bt =(1 << 1))

		//GPIOD->BSRR = (1 << 6);
//GPIOD->BSRR = (1 << (7+16) );

else if((GPIOD->IDR & 0x00000008) == 0x00000008) {
key_pressed = 2;	
lcd_cmd(0xC7); // line 2
lcd_cmd(0x01);
lcd_data('T');
lcd_data('E');
lcd_data('X');
lcd_data('T');
lcd_data(' ');
lcd_data('A');
lcd_data('C');
lcd_data('C');
lcd_data('E');
lcd_data('P');
lcd_data('T');
	
Delay(10);
GPIOD->IDR = 0x00000000;

/* Initialize GSM A6 Module */
	
	GSM_Init();

Phone_Receive_SMS();

}// End if( bt =(1 << 1))


else if((GPIOB->IDR & 0x00000008) == 0x00000008) {

	
	key_pressed = 3 ;

	USART2_Init();
	
	USART2_Write('3');
	
		c = USART2_Read();
		
		if(c == '3')
		{
			GPIOA->BSRR |= (1<<5); // led is turn ON
			//lcd_ini();
			lcd_cmd(0xC7); // line 2
      lcd_cmd(0x01);
//			USART2_Write('L');
//			USART_Text_Write("E\r");
//			USART_Text_Write("D\r");
//			USART_Text_Write("O\r");
//			USART_Text_Write("N\r");
			
lcd_data('L');
lcd_data('E');
lcd_data('D');
lcd_data(' ');
lcd_data('I');
lcd_data('S');
lcd_data(' ');
lcd_data('O');
lcd_data('N');
			
Delay(4);
			
		}
	else if(c != '3')
		{
		 GPIOA->BSRR |= (1<<21);  //  led is turn OFF	
//		  lcd_ini();
			lcd_cmd(0xC7); // line 2
      lcd_cmd(0x01);
//			USART_Text_Write("L\r");
//			USART_Text_Write("E\r");
//			USART_Text_Write("D\r");
//			USART_Text_Write("O\r");
//			USART_Text_Write("F\r");
//			USART_Text_Write("F\n");
			
lcd_data('L');
lcd_data('E');
lcd_data('D');
lcd_data(' ');
lcd_data('I');
lcd_data('S');
lcd_data(' ');
lcd_data('O');
lcd_data('F');
lcd_data('F');
			
			Delay(4);
		}

Delay(10);
GPIOB->IDR = 0x00000000;
}// End if( bt =(1 << 1))


///////////////////////////// 2nd row .... 

/*Row 1 = 1 & scanning of Col 1 , Col 2 , Col 3*/
 GPIOD->BSRR = ((1 << 6) );
GPIOD->BSRR = ((1 << (7 + 16)) );

 if((GPIOD->IDR & 0x00000002) == 0x00000002) {

	 key_pressed = 4 ;

	 USART2_Init();
	 
	 USART2_Write('4');
	
		c = USART2_Read();
		
		if(c != '4')
		{
			GPIOA->BSRR |= (1<<5); // led is turn ON
	//		lcd_ini();
			lcd_cmd(0xC7); // line 2
      lcd_cmd(0x01);
//			USART_Text_Write("L\r");
//			USART_Text_Write("E\r");
//			USART_Text_Write("D\r");
//			USART_Text_Write("O\r");
//			USART_Text_Write("N\r");
			
lcd_data('L');
lcd_data('E');
lcd_data('D');
lcd_data(' ');
lcd_data('I');
lcd_data('S');
lcd_data(' ');
lcd_data('O');
lcd_data('N');
			
			
			
			Delay(4);
			
		}
	else	if(c == '4')
		{
		 GPIOA->BSRR |= (1<<21);  //  led is turn OFF	
		//  lcd_ini();
			lcd_cmd(0xC7); // line 2
      lcd_cmd(0x01);
//			USART_Text_Write("L\r");
//			USART_Text_Write("E\r");
//			USART_Text_Write("D\r");
//			USART_Text_Write("O\r");
//			USART_Text_Write("F\r");
//			USART_Text_Write("F\n");
		
lcd_data('L');
lcd_data('E');
lcd_data('D');
lcd_data(' ');
lcd_data('I');
lcd_data('S');
lcd_data(' ');
lcd_data('O');
lcd_data('F');
lcd_data('F');
			
			Delay(4);
		}
			 	 
Delay(10);
GPIOD->IDR = 0x00000000;
 
 }// End if( bt =(1 << 1))
 
/*------------------------------------------------------------------------------
Add your code that monitors row 2,3,4 and scan continuously column 1, 2 and 3. 
Also display digit on LCD if any key pressed from row 2.
*---------------------------------------------------------------------*/
}

void lcd_ini(void)
{
 Delay(10);
 lcd_cmd(0x38);
 lcd_cmd(0x0C);
 lcd_cmd(0x01);
 Delay(10);
	
	}
void lcd_cmd(char i)
{
unsigned long r=0;
char loop=0;
r |= i;
for(loop=0;loop<=7;loop++)
{
 r = r << 1;
}
GPIOB->BSRR = ((1 << (1+16)));
LCDDATA = r;
GPIOE->ODR &= 0x000000FF;
GPIOE->ODR |= LCDDATA;
GPIOE->BSRR = ((1 << 7) );
Delay(10);
GPIOE->BSRR = ((1 << (7+16)));
}


void lcd_data(char j)
{ 
 unsigned long r=0;
char loop=0;
r |= j;
for(loop=0;loop<=7;loop++)
{
 r = r << 1;
}
GPIOB->BSRR = ((1 << 1) );
LCDDATA = r;
GPIOE->ODR &= 0x000000FF;
GPIOE->ODR |= LCDDATA;
GPIOE->BSRR = ((1 << 7) );
Delay(10);
GPIOE->BSRR = ((1 << (7+16)) ); 
}

void USART2_Init (void)
{
	RCC->APB1ENR |= (1<<17);
	RCC->AHB1ENR |= (1<<0);
	GPIOA-> AFR[0] |= (7<<12);
	GPIOA-> AFR[0] |= (7<<8); // alternate function register resistance 0 
	GPIOA->MODER |= (1<<7);  //  PA3 as Rx as a receiver  Alternate function mode 
	GPIOA->MODER |= (1<<5);  // PA2 as Tx as a transmitter Alternate function mode 
	
	USART2->BRR = 0x0683;  // 9600 at 16MHz
	USART2->CR1 |= (1<<2);   // Rx Enable
	USART2->CR1 |= (1<<3);   // Tx Enable
	USART2->CR1 |= (1<<13);  // USART Enable

	//USART2 -> CR3 |= (1 << 7); // DMA ENABLE transmitter 
	//USART2 -> CR3 |= (1 << 6); // DMA Enable Receiver
	
	Delay(100); // small delay of 100 milliseconds.
	
}

char USART2_Read(void)
{
	while(!(USART2-> SR & (1<<5))){}
	return USART2->DR;
	
}

char USART2_Write (char ch)
{
	// 7 th bit for transmission data 
	
	while(!(USART2-> SR & (1<<7))){}
		USART2-> DR = (ch & 0xff);
		return ch;
	
}

void USART_Text_Write( char *text)
{
	while(*text) USART2_Write(*text++);
	
}

void delayMS(int delay)
{
	int i;
	for( ;delay>0; delay--)
	   for(i= 0; i<=3195; i++);

}


int GSM_Compare_GSMData_With(const char* string)
{
	char* ptr = NULL;
  /*Compare given string with GSM data*/
	ptr = strstr(RX_Buffer, string);
	/* if ptr = NULL, then no match found else match found*/
  if(ptr!=NULL)
		return 1;
	else
		return 0;
}

void GSM_Send_AT_Command(char* AT_CMD)
{
	  while(*AT_CMD) USART2_Write(*AT_CMD);
}

void GSM_Send_SMS(char* Message, char* phone_number)
{
	char SMS_AT_CMD1[] = "AT+CMGF=1\r"; 
	char SMS_AT_CMD2[21] = "AT+CMGS=+923078554100";
	char CR[] = "\r";
	uint8_t MSG_END[] ={26};
	
	strcat(SMS_AT_CMD2, phone_number);
	strcat(SMS_AT_CMD2,CR);
	
	GSM_Send_AT_Command(SMS_AT_CMD1);
	Delay(1000);
	GSM_Send_AT_Command(SMS_AT_CMD2);
	Delay(1000);
	
	GSM_Send_AT_Command(Message);
	Delay(100);
	
	GSM_Send_AT_Command((char *)MSG_END);
	
	Delay(1000);
}

void GSM_Receive_SMS(void)
{
	char temp_buffer[RX_BUFFER_SIZE];
	int i=0,j=0,k=0,l=0,m=0;
	
	/*string pattern to detect start of phone number*/
   char phone_pattern[2] ={'"','+'};
 
    /* search for phone number */
    
	 char* ptr = strstr(temp_buffer,phone_pattern);

	 /*string patter to detect start of mesaage*/
    char sms_pattern[2] ={'6','"'};
	 
	/*Store RX_buffer values into temp_buffer*/

	 while(i<=127)
	{
		temp_buffer[i] = RX_Buffer[i];
		i++;	
	}
 
    /*store phone number*/
    for(j=0;j<13;j++)
    	Incoming_SMS_Phone_Num[j] = ptr[1+j];
 
   /*search for message */
   ptr = strstr(temp_buffer,sms_pattern);
  
   for(k=0;k<4;k++)
   {
	 ptr+=1; //Increment ptr
	 /*check if it is pointing to end of buffer*/
	 if(ptr == &temp_buffer[127])
	 {
		 if(k == 3)
		 {
			 Incoming_SMS_Message[l] = *(ptr+m);;
			 l++;
		 }
		 
		 ptr = &temp_buffer[0];  //if yes, goto start of buffer
	  }

	 }
  
    /*store the message untill "/r" is found, which indicates end of SMS*/
     while(*(ptr+m)!='\r')
     {
	 	if(ptr+m == &temp_buffer[127])
		{
			Incoming_SMS_Message[l] = *(ptr+m);
		    ptr = &temp_buffer[0];
			m = 0;
		}
		else
		{
			Incoming_SMS_Message[l] = *(ptr+m);
		    l++; 
		    m++;
    }	

  }

}     


void GSM_Init(void)
{
	/*Initialize UART*/
	USART2_Init();
	
	/* Start rceiving data as soon as data is available */
	//HAL_UART_Receive_DMA(&myUARThandle,(uint8_t *)RX_Buffer, RX_BUFFER_SIZE);
	
    /* Wait 15 to 20 Seconds - Let the GSM module get connected to network */
	Delay(100);
   
    /* Send Basic AT Commmand */
	GSM_Send_AT_Command("AT\r");
    Delay(1000);

    /*Selects SMS message format as text*/
    GSM_Send_AT_Command("AT+CMGF=1\r");
    Delay(1000);

    /*specify how newly arrived SMS messages should be handled*/
    GSM_Send_AT_Command("AT+CNMI=1,2,0,0,0\r");
    Delay(1000);
		
		GSM_Clear_RX_buffer();
}

void GSM_Clear_RX_buffer(void)
{
	int i;
	for(i=0;i<RX_BUFFER_SIZE;i++)
	   RX_Buffer[i] = '\r';
	
}


void Phone_Send_SMS(void)
{
	GSM_Send_SMS("Test Message","03078554100"); //As of now hardcoded SMS is sent.
	
	// Send SMS using Arduino and GSM Module � to a specified mobile number inside the program
	
			Delay(1000);  // Delay of 1000 milli seconds or 1 second
			GSM_Clear_RX_buffer();
	
	Delay(1000);
}

void Phone_Receive_SMS(void)
{
	GSM_Receive_SMS();  // Receive SMS using Arduino and GSM Module � to the SIM card loaded in the GSM Module.
	
		 Delay(1000);
	
	 GSM_Clear_RX_buffer();	
	
	Delay(1000);
}
